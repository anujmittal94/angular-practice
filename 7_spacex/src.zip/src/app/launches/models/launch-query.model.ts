export interface LaunchQuery {
  launch_success?: boolean;
  land_success?: boolean;
  launch_year?: number;
}
